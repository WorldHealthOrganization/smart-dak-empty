# Home - SMART DAK Empty v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/dak-empty/ImplementationGuide/smart.who.int.dak-empty | *Version*:0.1.0 |
| Draft as of 2026-02-18 | *Computable Name*:DAKEmpty |

 This DAK and set of implementation tools are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

**[Add content here. You could use as reference the previously published DAKs]**

### L1 Narrative guidelines

**[Add content here. You could use as reference the previously published DAKs]**

### L2 Operational guidelines

The DAK for **[insert health domain here]** and the associated implementations tools can be found here:

* [Published DAK Document]()

* Implementation tools:

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the **[insert health domain here]** SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

For more license details please see the [license page](https://smart.who.int/dak-<mark>[health domain abbreviation]</mark>/license.md).

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [dak-empty repository](https://github.com/WorldHealthOrganization/dak-empty)

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

